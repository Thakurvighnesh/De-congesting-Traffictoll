from airflow.hooks.S3_hook import S3Hook
from airflow.contrib.hooks.aws_hook import AwsHook
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from boto3.session import Session
import boto3
import logging

class DownloadfromS3Operator(BaseOperator):
    ui_color = '#358140'
    

    @apply_defaults
    def __init__(self,
                 aws_credentials_id="",
                 s3_bucket = "",
                 *args, **kwargs):

        super(DownloadfromS3Operator, self).__init__(*args, **kwargs)
        self.aws_credentials_id = aws_credentials_id
        self.s3bucket = s3_bucket
        
        
    def execute(self, context):
        """
        redshift_conn_id: redshift cluster connection info.
        aws_credentials_id: necessary info needed to make AWS connection
        s3_bucket: source data in S3 bucket that has the files we want to copy from.
        """
        self.log.info('StageToRedshiftOperator not implemented yet')
        hook = S3Hook(self.aws_credentials_id)
        bucket = self.s3bucket
        keys = hook.list_keys(bucket)
        aws_hook = AwsHook(self.aws_credentials_id)
        credentials = aws_hook.get_credentials()
        session = Session(aws_access_key_id=credentials.access_key,
                      aws_secret_access_key=credentials.secret_key)
        for key in keys:
            logging.info(f"--------------- s3://{bucket}/{key} -----------")
            session.resource('s3').Bucket(bucket).download_file(key,'/home/workspace/uk-data/' + key)